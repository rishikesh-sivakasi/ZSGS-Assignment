package Exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class PhoneNumberCheck {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        try {
            System.out.print("Enter your phone number: ");
            long phoneNumber = sc.nextLong();
            System.out.println("Your phone number is: " + phoneNumber);
        } catch (InputMismatchException e) {
            System.out.println("Enter only numbers for the phone number.");
        } finally {
            sc.close();
        }
    }
}
